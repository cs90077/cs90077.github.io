//
//  PhotoFooterView.swift
//  ltt_collectionview_compositional_layout
//
//  Created by 林東東 on 2021/10/28.
//

import UIKit

class PhotoFooterView: UICollectionReusableView {

    static let identifier = "PhotoFooterView"
    
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
