//
//  PhotoHeaderView.swift
//  ltt_collectionview_compositional_layout
//
//  Created by 林東東 on 2021/10/28.
//

import UIKit

class PhotoHeaderView: UICollectionReusableView {
    
    static let identifier = "PhotoHeaderView"
    
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
