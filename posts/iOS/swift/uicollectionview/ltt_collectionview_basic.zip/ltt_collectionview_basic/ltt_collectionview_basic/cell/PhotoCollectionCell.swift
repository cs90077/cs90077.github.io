//
//  PhotoCollectionCell.swift
//  ltt_collectionview_compositional_layout
//
//  Created by 林東東 on 2021/10/27.
//

import UIKit

class PhotoCollectionCell: UICollectionViewCell {
    
    static let identifier = "PhotoCollectionCell"
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var lblTitle: UILabel!
    
}

