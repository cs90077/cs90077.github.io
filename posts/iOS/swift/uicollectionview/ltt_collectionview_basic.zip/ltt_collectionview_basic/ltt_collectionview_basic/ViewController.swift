//
//  ViewController.swift
//  ltt_collectionview_basic
//
//  Created by 林東東 on 2021/10/27.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var fullScreenSize :CGSize = UIScreen.main.bounds.size
    
    var dataSource: [[Int]] = []
        
    lazy var layout: UICollectionViewFlowLayout = {
        // 建立 UICollectionViewFlowLayout
        let layout = UICollectionViewFlowLayout()

        // 設置 section 的間距 四個數值分別代表 上、左、下、右 的間距
        layout.sectionInset = UIEdgeInsets.init(top: 5, left: 5, bottom: 5, right: 5)

        // 設置每一行的間距
        layout.minimumLineSpacing = 5

        // 設置每個 cell 的尺寸
        layout.itemSize = CGSize(width: CGFloat(fullScreenSize.width)/3 - 10.0, height: CGFloat(fullScreenSize.width)/3 - 10.0)
        
        // 設置 header 及 footer 的尺寸
        layout.headerReferenceSize = CGSize(
          width: fullScreenSize.width, height: 40)
        layout.footerReferenceSize = CGSize(
          width: fullScreenSize.width, height: 40)
        return layout
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupCollectionView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       
        self.reloadData()
    }
    
    func setupCollectionView() {
        collectionView.dataSource = self
        collectionView.delegate = self
        
        // flowlayout
        collectionView.collectionViewLayout = layout
        
        // cell
        collectionView.register(UINib(nibName: PhotoCollectionCell.identifier, bundle: nil), forCellWithReuseIdentifier: PhotoCollectionCell.identifier)
        
        // header
        collectionView.register(UINib(nibName: PhotoHeaderView.identifier, bundle: nil), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: PhotoHeaderView.identifier)
        
        // footer
        collectionView.register(UINib(nibName: PhotoFooterView.identifier, bundle: nil), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: PhotoFooterView.identifier)
    }
    
    func reloadData() {
        for _ in 1...2 {
            var ary: [Int] = []
            
            for i in 1...9 {
                ary.append(i)
            }
            
            dataSource.append(ary)
        }
            
        self.collectionView.reloadData()
    }
    
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return dataSource.count
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        if kind == UICollectionView.elementKindSectionHeader {
            guard let reusableView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: PhotoHeaderView.identifier, for: indexPath)
                    as? PhotoHeaderView else { return UICollectionReusableView() }
            
            reusableView.lblTitle.text = "Header"
            reusableView.lblTitle.textColor = .white
            reusableView.backgroundColor = .darkGray
            return reusableView
        }
        else if kind == UICollectionView.elementKindSectionFooter {
            guard let reusableView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: PhotoFooterView.identifier, for: indexPath)
                    as? PhotoFooterView else { return UICollectionReusableView() }
            
            reusableView.lblTitle.text = "Footer"
            reusableView.lblTitle.textColor = .white
            reusableView.backgroundColor = .lightGray
            return reusableView
        }
                
        return UICollectionReusableView()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataSource[section].count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoCollectionCell.identifier, for: indexPath) as? PhotoCollectionCell else {
            return UICollectionViewCell()
        }
        
        let data = dataSource[indexPath.section][indexPath.row]
        cell.backgroundColor = .clear
        cell.imageView.image = UIImage(named: "img_smile")
        cell.lblTitle.text = data.description
                
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // click
        print("index = \(indexPath.row)")
    }
    
}
